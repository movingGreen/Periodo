﻿using System;

namespace FirstSolution.Domain.DTO
{
    public class Class1
    {
    }
}
