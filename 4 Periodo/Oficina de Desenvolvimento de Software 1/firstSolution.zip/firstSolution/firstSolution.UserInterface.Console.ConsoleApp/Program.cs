﻿using First.Solution.Domain.ProjectDomain;
using System.Reflection;
using System.Text.Json;
using System.Text.Json;

class Program
{
    private static void Main(string[] args)
    {
        var pessoa = new Pessoa();
        
        Console.WriteLine("Digite as informações da pessoa");
        Console.WriteLine("Id: ");
        pessoa.PessoaId = Int32.Parse(Console.ReadLine());

        Console.WriteLine("Nome: ");
        pessoa.Nome = Console.ReadLine();

        Console.WriteLine("Data de Nascimento: ");
        pessoa.DataNascimento = DateTime.Parse(Console.ReadLine());

        // Instanciar Tipo de Atividade

        var tipoDeAtividade = new TipoAtividade();

        Console.WriteLine("Digite as informações do tipo atividade");
        Console.WriteLine("Id: ");
        tipoDeAtividade.TipoAtividadeId = Int32.Parse(Console.ReadLine());

        Console.WriteLine("Descrição: ");
        tipoDeAtividade.Descricao = Console.ReadLine();

        // Instanciar Atividade Complementar

        var complemento1 = new AtividadeComplementar();
        complemento1.Aluno = pessoa;
        complemento1.Tipo = tipoDeAtividade;

        Console.WriteLine("Digite as informações da atividade complementar");
        Console.WriteLine("Id: ");
        complemento1.AtividadeComplementarId = Int32.Parse(Console.ReadLine());

        Console.WriteLine("Data: ");
        complemento1.Data = DateTime.Parse(Console.ReadLine());

        Console.WriteLine("Nome da instituição: ");
        complemento1.Instituicao = Console.ReadLine();

        Console.WriteLine("Ano de formação: ");
        complemento1.AnoFormacao = int.Parse(Console.ReadLine());   


        Console.WriteLine("\n");
        Console.WriteLine("===== Dados =====");
        //LoopThroughProperties(complemento1);
        var options = new JsonSerializerOptions
        {
            WriteIndented = true
        };

        Console.WriteLine(JsonSerializer.Serialize(complemento1, options));

        // Função looping sobre os dados
        static void LoopThroughProperties(object obj)
        {
            Type type = obj.GetType();
            PropertyInfo[] properties = type.GetProperties();

            foreach (PropertyInfo property in properties)
            {
                object value = property.GetValue(obj, null);
                Console.WriteLine("{0}: {1}", property.Name, value);
            }
        }
    }
}