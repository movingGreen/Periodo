﻿

namespace First.Solution.Domain.ProjectDomain
{
    public class TipoAtividade
    {
        public int TipoAtividadeId { get; set; }
        public string Descricao { get; set; }

    }
}
