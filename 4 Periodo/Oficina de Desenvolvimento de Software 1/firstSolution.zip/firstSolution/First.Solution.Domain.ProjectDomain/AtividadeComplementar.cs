﻿using System;

namespace First.Solution.Domain.ProjectDomain
{
    public class AtividadeComplementar
    {
        public int AtividadeComplementarId { get; set; }
        public DateTime Data { get; set; }
        public Pessoa Aluno { get; set; }
        public TipoAtividade Tipo { get; set; }
        public string Instituicao { get; set; }
        public int AnoFormacao { get; set; }
    }
}
