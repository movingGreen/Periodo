﻿using System;

namespace FirstSolution.UserInterface.Desktop.Pessoas
{
    public class Class1
    {
    }
}
