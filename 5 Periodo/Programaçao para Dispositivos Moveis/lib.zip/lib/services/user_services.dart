import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class UserServices {
  FirebaseAuth auth = FirebaseAuth.instance;

  bool signUp(String userEmail, String password) {
    try {
      auth.createUserWithEmailAndPassword(email: userEmail, password: password);
      return true;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        debugPrint("Usuário não existe!");
      } else if (e.code == 'wrong-password') {
        debugPrint("A senha informada está incorreta!");
      }
      return false;
    } catch (f) {
      debugPrint(f.toString());
      return false;
    }
  }
}
