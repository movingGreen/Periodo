@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://servico.cba.ifmt/")
package ifmt.cba.servico;
